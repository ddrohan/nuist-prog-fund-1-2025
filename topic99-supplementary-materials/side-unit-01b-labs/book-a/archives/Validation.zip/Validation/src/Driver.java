public class Driver {

        public static void main(String args[]) {
                //Using less modern  validation techniques
                SpotWithValidation1 spot1 = new SpotWithValidation1(10, 1000, "Older Method of Validation"); //note this description is too long
                System.out.println("Calling print on constructed spot - should be defaulted ");
                System.out.println(spot1.toString());
                System.out.println("Trying setter with invalid value (-200)");
                spot1.setX(-200);
                System.out.println("Calling print  - x value should not have changed");
                System.out.println(spot1);

                // Now use the new validation technique. We will use this form of validation during this module.
                SpotWithValidation2 spot2 = new SpotWithValidation2(10, 1000, "More Modern Method ");
                System.out.println("Calling print on constructed spot - should be defaulted ");
                System.out.println(spot2.toString());
                System.out.println("Trying setter with invalid value (-200)");
                spot2.setX(-200);
                System.out.println("Calling print  - x value should not have changed");
                System.out.println(spot2);
    }
}
